package com.workHours;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.SendResult;

/**
 *
 * @author kamil
 */
public class WorkingHours extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        try {
            
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sdp_schema?useSSL=false","root","password");
           
            String start_week_date = request.getParameter("start_week_date" ).replaceAll("\\s+","");
            String project_id = request.getParameter("project_id").replaceAll("\\s+","");
            String employee_id = request.getParameter("employee_id").replaceAll("\\s+","");
            
            String monday = request.getParameter("Monday");
            String tuesday = request.getParameter("Tuesday");
            String wednesday = request.getParameter("Wednesday");
            String thursday = request.getParameter("Thursday");
            String friday = request.getParameter("Friday");
            String saturday = request.getParameter("Saturday");
            String sunday = request.getParameter("Sunday");
            

            if(project_id.isEmpty() || project_id==null){
                
                System.out.println("Project id is empty");
                response.sendRedirect("welcomeFailed.jsp");
               
            } else {
                
              
                String days[] = {monday, tuesday, wednesday, thursday, friday, saturday, sunday};

                for (int i=0;i<days.length;i++){

                    if(days[i]==null || days[i]=="" )
                    {
                        days[i]="0";
                    }

                }
                
            /*
                HERE if the CODE is incorrect */
                
            String queryPidIsBas = "SELECT * FROM EMPLOYEES_PROJECTS WHERE PROJECT_ID = ? ";
            PreparedStatement psPidIsBas = connection.prepareStatement(queryPidIsBas);
            psPidIsBas.setString(1, project_id);
            ResultSet rsPidIsBas = psPidIsBas.executeQuery();
            
            if(rsPidIsBas.next()==false) {
                response.sendRedirect("welcomeFailed.jsp");
            } else {

                String queryInsertHours = "INSERT INTO WORKING_HOURS (EMPLOYEE_ID, PROJECT_ID, START_DATE, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, "
                       + "   FRIDAY, SATURDAY, SUNDAY)  VALUES "
                       + "( "
                       + Integer.parseInt(employee_id)+" , "
                       + Integer.parseInt(project_id)+" , "
                       + "'"+start_week_date+"' ,"
                       + days[0]+ " ,  "
                       + days[1]+ " , "
                       + days[2]+" , "
                       + days[3]+" , "
                       + days[4]+" , "
                       + days[5]+" , "
                       + days[6]+" ) "
                       + "ON DUPLICATE KEY UPDATE "
                       + "MONDAY = "+ days[0]+ " ,  "
                       + "TUESDAY = "+ days[1]+ " ,  "
                       + "WEDNESDAY = "+ days[2]+ " ,  "
                       + "THURSDAY = "+ days[3]+ " ,  "
                       + "FRIDAY = "+ days[4]+ " ,  "
                       + "SATURDAY = "+ days[5]+ " ,  "
                       + "SUNDAY = "+ days[6]+ " ";

                    PreparedStatement psQuery = connection.prepareStatement(queryInsertHours);

                    int rsQuery = psQuery.executeUpdate();

                    psQuery.close();
                    connection.close();

                    response.sendRedirect("welcome.jsp");

                }
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(WorkingHours.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(WorkingHours.class.getName()).log(Level.SEVERE, null, ex);
        }
        
     
    }
}
