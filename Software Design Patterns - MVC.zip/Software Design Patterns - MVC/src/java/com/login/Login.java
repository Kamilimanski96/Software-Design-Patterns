/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author kamil
 */
public class Login extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
        String input_email = request.getParameter("email");
        String input_password = request.getParameter("password");
        
        try {  
            
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sdp_schema?useSSL=false","root","password");
            
            PreparedStatement psQuery1 = connection.prepareStatement("SELECT * FROM EMPLOYEES WHERE EMAIL = ? ");
            psQuery1.setString(1, input_email);
            
            ResultSet rsQuery1 = psQuery1.executeQuery();
            
            while(rsQuery1.next()){
                
                int id = rsQuery1.getInt("EMPLOYEE_ID");
                String password = rsQuery1.getString("password");
                
                if(input_password.equals(password)){
                    
                    HttpSession session = request.getSession();
                    session.setAttribute("user_id", id);
                    
                    response.sendRedirect("welcome.jsp");
                    
                } else {
                    response.sendRedirect("loginFailed.jsp");
                }
                
            }
            
            rsQuery1.close();
            connection.close();
            
            
           
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
       
        
    }

}
